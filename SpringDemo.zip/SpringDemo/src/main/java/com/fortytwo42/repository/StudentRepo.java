package com.fortytwo42.repository;

import java.util.List;
import java.util.Map;

import com.fortytwo42.model.UpdateDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.fortytwo42.model.Student;

@Repository
public class StudentRepo {

	@Autowired
	private JdbcTemplate jdbc;
	@Autowired
	private SubjectRepo subjectRepo;

	public boolean insertStudent(Student student) throws Exception {
		String sql = "INSERT INTO `Student` (`firstname`, `lastname`, `coursename`,`emailid`,`mobno`) values (?,?,?,?,?)";
		String sqlsub = "insert into Stud_Sub (Stud_id,Sub_id) values(?,?)";

		int result = jdbc.update(sql, student.getFirstname(), student.getLastname(), student.getCoursename(),student.getEmailid(),student.getMobno());
		if (result > 0) {
			String sqlgetid = "SELECT roll_no from Student where emailid=?";
			String email= student.getEmailid();
			int id= jdbc.queryForObject(sqlgetid, new Object[] {email}, Integer.class);
			
			for(String subject:student.getSubject())
			{
				int subid=subjectRepo.getSubjectIdFromSubject(subject);
				int resultsub = jdbc.update(sqlsub,id,subid);

			}	
			return true;
		}
		return false;
	}

	public Student getStudetnByEmailId(String email) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM Student WHERE emailid=?";

		Student student = new Student();
		
		List<Map<String, Object>> rows = jdbc.queryForList(sql,new Object[]{email});

        if(rows.isEmpty())
		{
			System.out.println("no record");
			return  null;
		}
        
        Map row= rows.get(0);
        student.setSid(new Integer(row.get("roll_no").toString()));
        student.setFirstname(row.get("firstname").toString());
        student.setLastname(row.get("lastname").toString());
        student.setCoursename(row.get("coursename").toString());
        student.setEmailid(row.get("emailid").toString());
        student.setMobno(row.get("mobno").toString());

        return student;
	}

	public int updateStudent(UpdateDto updateDto) throws Exception {

		String sqlsub = "insert into Stud_Sub (Stud_id,Sub_id) values(?,?)";
		int resultsub=0;
			for(String subject: updateDto.getSubList())
			{
				int subid=subjectRepo.getSubjectIdFromSubject(subject);
				
				if(!subjectRepo.isPresentStudWithSub(updateDto.getId(),subid) && isPresent(updateDto.getId())) {
					 resultsub = jdbc.update(sqlsub, updateDto.getId(), subid);
				}

			}

			return resultsub;
		}

	 public boolean isPresent(int id) {

	String sql = "SELECT count(*) FROM Student WHERE roll_no =?";

	int count = jdbc.queryForObject(sql, new Object[] { id }, Integer.class);

		return count > 0;
	}

	public int deleteStudent(int id) {
		String sql = "delete from Student where roll_no=?";

		return jdbc.update(sql, id);
	}

}
