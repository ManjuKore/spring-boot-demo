package com.fortytwo42.repository;

import com.fortytwo42.model.Student;
import com.fortytwo42.model.Teacher;
import com.fortytwo42.model.UpdateDto;
import com.fortytwo42.model.UpdateSubjectDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public class TeacherRepo {
    @Autowired
    private JdbcTemplate jdbc;
    @Autowired
    private SubjectRepo subjectRepo;

    public boolean insertTeacher(Teacher teacher) throws Exception {
        String sql = "INSERT INTO Teacher (firstname,lastname,qualification,emailid,mobno) values (?,?,?,?,?)";
        String sqlsub = "insert into Teach_Sub (t_id,sub_id) values(?,?)";

        int result = jdbc.update(sql,teacher.getFirstname(),teacher.getLastname(),teacher.getQualification(),teacher.getEmailid(),teacher.getMobno());
        if (result > 0) {
            String sqlgetid = "SELECT t_id from Teacher where emailid=?";

            int id= jdbc.queryForObject(sqlgetid, new Object[] {teacher.getEmailid()}, Integer.class);
            for(String subject:teacher.getSubject())
            {
                int subid=subjectRepo.getSubjectIdFromSubject(subject);
                int resultsub = jdbc.update(sqlsub,id,subid);

            }

            return true;
        }
        return false;



    }


    public Teacher getTeacherByEmailId(String emailid) {

        String sql = "SELECT * FROM Teacher WHERE emailid=?";

        Teacher teacher = new Teacher();
        List<Map<String, Object>> rows = jdbc.queryForList(sql,new Object[]{emailid});

        if(rows.isEmpty())
        {
            System.out.println("no record");
            return  null;
        }
        Map row= rows.get(0);
        teacher.setTeacherid(new Integer(row.get("t_id").toString()));
        teacher.setFirstname(row.get("firstname").toString());
        teacher.setLastname(row.get("lastname").toString());
        teacher.setQualification(row.get("qualification").toString());
        teacher.setEmailid(row.get("emailid").toString());
        teacher.setMobno(row.get("mobno").toString());


        return teacher;


    }

    public int updateTeacher(UpdateDto teacher) throws Exception {

        String sqlsub = "insert into Teach_Sub (t_id,sub_id) values(?,?)";
        int resultsub=0;
        for(String subject: teacher.getSubList())
        {
            int subid=subjectRepo.getSubjectIdFromSubject(subject);
            if(!subjectRepo.isPresentSubjectWithTeacher(teacher.getId(),subid)&&isPresent(teacher.getId())) {
                resultsub = jdbc.update(sqlsub, teacher.getId(), subid);
            }

        }
        return resultsub;
    }

    public int updateSubject(UpdateSubjectDto subjectDto) {

        String sqlsub = "insert into Teach_Sub (t_id,sub_id) values(?,?)";
        int resultsub=0;
        for(String email: subjectDto.getTeacherEmailId())
        {
            Teacher teacher=getTeacherByEmailId(email);
            if(!subjectRepo.isPresentSubjectWithTeacher(teacher.getTeacherid(),subjectDto.getId())&&subjectRepo.isPresentsubject(subjectDto.getId())) {
                resultsub = jdbc.update(sqlsub, teacher.getTeacherid(), subjectDto.getId());
            }

        }
        return resultsub;
    }

    private boolean isPresent(int id) {
        String sql = "SELECT count(*) FROM Teacher WHERE t_id =?";

        int count = jdbc.queryForObject(sql, new Object[] { id }, Integer.class);

        return count > 0;


    }
}
