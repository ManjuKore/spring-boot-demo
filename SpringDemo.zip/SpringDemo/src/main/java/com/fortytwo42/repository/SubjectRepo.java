package com.fortytwo42.repository;

import com.fortytwo42.model.Student;
import com.fortytwo42.model.Teacher;
import com.fortytwo42.model.UpdateSubjectDto;
import com.fortytwo42.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.fortytwo42.model.Subject;

import java.util.List;
import java.util.Map;

@Repository
public class SubjectRepo {


	@Autowired
	private JdbcTemplate jdbc;


	public boolean insertSubject(Subject subject) {
		String sql = "INSERT INTO `Subject` (`subjectname`) values (?)";

		int result = jdbc.update(sql, subject.getSubname());
		if (result > 0) {
			return true;
		}
		return false;
	}


	public int getSubjectIdFromSubject(String subject) throws Exception {

		String sql = "SELECT * FROM Subject WHERE subjectname=?";


		List<Map<String, Object>> rows = jdbc.queryForList(sql,new Object[]{subject});

		if(rows.isEmpty())
		{
			System.out.println("Please add proper subject");
			throw new Exception("Subject not Exist");
		}
		return new Integer(rows.get(0).get("sub_id").toString());

	}

    public boolean isPresentStudWithSub(int id, int subid) {
		String sql = "SELECT count(*) FROM Stud_Sub WHERE Stud_id = ? AND Sub_id=?";

		int count = jdbc.queryForObject(sql, new Object[] { id,subid }, Integer.class);

		return count > 0;
    }

	public boolean isPresentSubjectWithTeacher(int id, int subid) {
		String sql = "SELECT count(*) FROM Teach_Sub WHERE t_id = ? AND sub_id=?";

		int count = jdbc.queryForObject(sql, new Object[] { id,subid }, Integer.class);

		return count > 0;

	}


	public boolean isPresentsubject(int id) {
		String sql = "SELECT count(*) FROM Subject WHERE sub_id=?";

		int count = jdbc.queryForObject(sql, new Object[] { id}, Integer.class);

		return count > 0;

	}
}
