package com.fortytwo42.service;

import com.fortytwo42.model.Subject;
import com.fortytwo42.model.UpdateSubjectDto;

public interface SubjectService {
	
	boolean insertSubject(Subject subject);

    int updateSubject(UpdateSubjectDto subjectDto);
}
