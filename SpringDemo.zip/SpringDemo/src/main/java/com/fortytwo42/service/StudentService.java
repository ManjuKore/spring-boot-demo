package com.fortytwo42.service;

import com.fortytwo42.model.Student;
import com.fortytwo42.model.UpdateDto;

public interface StudentService {

	 boolean insertStudent(Student student) throws Exception;
	 Student getStudentByEmailId(String email);
	 int updateStudent(UpdateDto updateDto) throws Exception;
	 int deleteStudent(int id);
}
