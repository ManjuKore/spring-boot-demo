package com.fortytwo42.service;

import com.fortytwo42.model.Teacher;
import com.fortytwo42.model.UpdateDto;

public interface TeacherService {

	boolean insertTeacher(Teacher teacher) throws Exception;

    int updateTeacher(UpdateDto teacher) throws Exception;

    Teacher getTeacherOfEmail(String emailid);
}
