package com.fortytwo42.service;

import com.fortytwo42.model.UpdateSubjectDto;
import com.fortytwo42.repository.TeacherRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fortytwo42.model.Subject;
import com.fortytwo42.repository.SubjectRepo;

@Service
public class SubjectServiceImpl implements SubjectService{

	@Autowired
	SubjectRepo subjectRepo;
	@Autowired
	TeacherRepo teacherRepo;

	@Override
	public boolean insertSubject(Subject subject) {
		// TODO Auto-generated method stub
		if(subject==null)
		{
			return false;
		}
		return subjectRepo.insertSubject(subject);

	}

	@Override
	public int updateSubject(UpdateSubjectDto subjectDto) {
		if(subjectDto.getId()<=0)
		{
			return  0;
		}
		return teacherRepo.updateSubject(subjectDto);
	}


}
