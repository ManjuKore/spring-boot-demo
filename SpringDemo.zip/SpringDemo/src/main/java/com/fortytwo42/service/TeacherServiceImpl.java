package com.fortytwo42.service;

import com.fortytwo42.model.Teacher;
import com.fortytwo42.model.UpdateDto;
import com.fortytwo42.repository.TeacherRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeacherServiceImpl implements TeacherService{
    @Autowired
    TeacherRepo teacherRepo;
    @Override
    public boolean insertTeacher(Teacher teacher) throws Exception {
        if(teacher==null || null!=getTeacherOfEmail(teacher.getEmailid()))
        {
            return false;
        }
        return teacherRepo.insertTeacher(teacher);
    }

    @Override
    public int updateTeacher(UpdateDto teacher) throws Exception {
        if(teacher.getId()<=0)
        {
            return 0;
        }
        return teacherRepo.updateTeacher(teacher);

    }

    public Teacher getTeacherOfEmail(String emailid) {

        return teacherRepo.getTeacherByEmailId(emailid);
    }
}
