package com.fortytwo42.service;

import com.fortytwo42.model.UpdateDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fortytwo42.model.Student;
import com.fortytwo42.repository.StudentRepo;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	StudentRepo studentRepo;

	@Override
	public boolean insertStudent(Student student) throws Exception {
		// TODO Auto-generated method stub
		if(student==null || getStudentByEmailId(student.getEmailid())!=null)
		{
			return false;
		}
		return studentRepo.insertStudent(student);

	}

	@Override
	public int deleteStudent(int id) {
		if(studentRepo.isPresent(id))
		{
			return studentRepo.deleteStudent(id);
		}
		return 0;
	}

	@Override
	public Student getStudentByEmailId(String email) {
		// TODO Auto-generated method stub

		return studentRepo.getStudetnByEmailId(email);
	}

	@Override
	public int updateStudent(UpdateDto updateDto) throws Exception {
		if(updateDto.getId()<=0)
		{
			return 0;
		}
		return studentRepo.updateStudent(updateDto);
	}

}
