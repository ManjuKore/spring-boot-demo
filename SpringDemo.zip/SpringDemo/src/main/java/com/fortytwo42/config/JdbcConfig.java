package com.fortytwo42.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class JdbcConfig {
	
	@Bean
	public DataSource getdatasource() {
		DriverManagerDataSource driver = new DriverManagerDataSource();
		driver.setDriverClassName(DatabaseConstants.DATABASEDRIVERNAME);
		driver.setUrl(DatabaseConstants.URL);
		driver.setUsername(DatabaseConstants.USERNAME);
		driver.setPassword(DatabaseConstants.PASSWORD);
		return driver;

	}

	@Bean
	@Autowired
	public JdbcTemplate jdbctemplate(DataSource datasource) {
		return new JdbcTemplate(datasource);
	}


}
