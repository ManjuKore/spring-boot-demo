package com.fortytwo42.config;

public class DatabaseConstants {

    public static final String DATABASEDRIVERNAME="com.mysql.jdbc.Driver";
    public static final String URL="jdbc:mysql://localhost:3306/school";
    public static final String USERNAME="manju";
    public static final String PASSWORD="Manju@12";
}
