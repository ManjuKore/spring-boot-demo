package com.fortytwo42.controller;

import com.fortytwo42.model.UpdateDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fortytwo42.model.Student;
import com.fortytwo42.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	StudentService studServ;

	@RequestMapping(value = "/addStudent",method = 	RequestMethod.POST)
	public ResponseEntity<?> insertStudent(Student student) throws Exception {
			if(studServ.insertStudent(student)){
				return new ResponseEntity<String>("Student added",HttpStatus.OK);
			}
		return new ResponseEntity<String>("Email already exist",HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/editStudent",method = 	RequestMethod.PUT)
	public ResponseEntity<?> updateStudent(UpdateDto student) throws Exception {
		if(studServ.updateStudent(student)>0){
			return new ResponseEntity<String>("Student updated",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Error in Update Student!!",HttpStatus.BAD_REQUEST);
	}

	@RequestMapping(value = "/deleteStudent/{studentid}",method = 	RequestMethod.DELETE)
	public ResponseEntity<?> updateStudent(@PathVariable(value = "studentid") int studentid) throws Exception {
		if(studServ.deleteStudent(studentid)>0){
			return new ResponseEntity<String>("Student deleted",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Error in Delete Student!!",HttpStatus.BAD_REQUEST);
	}






}
