package com.fortytwo42.controller;

import com.fortytwo42.model.Student;
import com.fortytwo42.model.Teacher;
import com.fortytwo42.model.UpdateDto;
import com.fortytwo42.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TeacherController {
    @Autowired
    TeacherService teacherService;

    @RequestMapping(value = "/addTeacher",method = 	RequestMethod.POST)
    public ResponseEntity<?> insertTeacher(Teacher teacher) throws Exception {
        if(teacherService.insertTeacher(teacher)){
            return new ResponseEntity<String>("Teacher added", HttpStatus.OK);
        }
        return new ResponseEntity<String>("Email already exist",HttpStatus.BAD_REQUEST);
    }

    @RequestMapping(value = "/editTeacher",method = 	RequestMethod.PUT)
    public ResponseEntity<?> updateTeacher(UpdateDto teacher) throws Exception {
        if(teacherService.updateTeacher(teacher)>0){
            return new ResponseEntity<String>("Teacher updated",HttpStatus.OK);
        }
        return new ResponseEntity<String>("Error in Update Teacher!!",HttpStatus.BAD_REQUEST);
    }
}
