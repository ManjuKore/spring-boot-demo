package com.fortytwo42.controller;

import com.fortytwo42.model.UpdateDto;
import com.fortytwo42.model.UpdateSubjectDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fortytwo42.model.Subject;
import com.fortytwo42.service.SubjectService;

@RestController
public class SubjectController {

	@Autowired
	SubjectService subServ;

	@RequestMapping(value = "/addSubject",method = 	RequestMethod.POST)
	public boolean insertSubject(Subject subject)
	{
			return subServ.insertSubject(subject);
	}

	@RequestMapping(value = "/editSubject",method = 	RequestMethod.PUT)
	public ResponseEntity<?> updateSubject(UpdateSubjectDto subjectDto) throws Exception {
		if(subServ.updateSubject(subjectDto)>0){
			return new ResponseEntity<String>("Subject Teacher updated", HttpStatus.OK);
		}
		return new ResponseEntity<String>("Error in Updating Subject!!",HttpStatus.BAD_REQUEST);
	}

}
