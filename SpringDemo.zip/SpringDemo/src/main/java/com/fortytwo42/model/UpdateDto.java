package com.fortytwo42.model;

import java.util.List;

public class UpdateDto {

    private int id;
    private List<String> subList;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<String> getSubList() {
        return subList;
    }

    public void setSubList(List<String> subList) {
        this.subList = subList;
    }
}
