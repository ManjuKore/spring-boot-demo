package com.fortytwo42.model;

import java.util.List;

public class UpdateSubjectDto {

    int id;
    List<String> teacherEmailId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<String> getTeacherEmailId() {
        return teacherEmailId;
    }

    public void setTeacherEmailId(List<String> teacherEmailId) {
        this.teacherEmailId = teacherEmailId;
    }
}
