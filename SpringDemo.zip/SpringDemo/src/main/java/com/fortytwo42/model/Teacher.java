package com.fortytwo42.model;

import java.util.Set;

public class Teacher {
	
	private int teacherid;
	private String firstname;
	private String lastname;
	private String qualification;
	private String emailid;
	private Set<String> subject;
	private String mobno;

	public String getMobno() {
		return mobno;
	}

	public void setMobno(String mobno) {
		this.mobno = mobno;
	}

	public Teacher(int teacherid, String firstname, String lastname, String qualification, String emailid, Set<String> subject) {
		this.teacherid = teacherid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.qualification = qualification;
		this.emailid = emailid;
		this.subject = subject;
	}

    public Teacher() {

    }

    public int getTeacherid() {
		return teacherid;
	}

	public void setTeacherid(int teacherid) {
		this.teacherid = teacherid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public Set<String> getSubject() {
		return subject;
	}

	public void setSubject(Set<String> subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "Teacher{" +
				"teacherid=" + teacherid +
				", firstname='" + firstname + '\'' +
				", lastname='" + lastname + '\'' +
				", qualification='" + qualification + '\'' +
				", emailid='" + emailid + '\'' +
				", subject=" + subject +
				'}';
	}
}

