package com.fortytwo42.model;

import java.util.List;

public class Student {

	private int sid;
	private String firstname;
	private String lastname;
	private String coursename;
	private String emailid;
	private String mobno;
	private List<String> subject;
	

	public Student(String firstname, String lastname, String coursename, String emailid, String mobno,
			List<String> subject,int sid) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.coursename = coursename;
		this.emailid = emailid;
		this.mobno = mobno;
		this.subject = subject;
		this.sid=sid;
	}
		
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public List<String> getSubject() {
		return subject;
	}
	public void setSubject(List<String> subject) {
		this.subject = subject;
	}
	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}	

	@Override
	public String toString() {
		return "Student [firstname=" + firstname + ", lastname=" + lastname + ", coursename=" + coursename
				+ ", emailid=" + emailid + ", mobno=" + mobno + ", subject=" + subject + "]";
	}


}
